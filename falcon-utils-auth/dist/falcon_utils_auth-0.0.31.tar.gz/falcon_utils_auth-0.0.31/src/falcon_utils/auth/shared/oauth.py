



# class OAuth:

#     def __init__(self, url: str=None, headers: dict = None, is_async=True)
#         self.__is_async = is_async
    
#     def validate(self, token: str):
#         signing_key = self.__oauth_client.

class AsyncOAuthClient:

    def __init__(self):
        pass

class OAuthClient:

    def __init__(self):
        pass